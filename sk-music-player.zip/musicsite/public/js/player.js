'use strict';

const $ = (id) => document.getElementById(id);
const audio = $('audio');
const ICON = {
  play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>',
  vol: '<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>',
  mute: '<svg viewBox="0 0 24 24"><path d="M16.5 12A4.5 4.5 0 0 0 14 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0 0 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 0 0 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4 9.91 6.09 12 8.18V4z"/></svg>'
};

let songs = [];
let current = null;      // currently loaded song object
let dragging = false;
let shuffle = false;
let repeat = false;
let lastSig = '';

/* ---------- storage helpers (private browsing safe) ---------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (_) { /* ignore */ } }
};

/* ---------- library ---------- */
function filtered() {
  const q = $('q').value.trim().toLowerCase();
  if (!q) return songs;
  return songs.filter((s) => (s.title + ' ' + (s.artist || '')).toLowerCase().includes(q));
}

function render() {
  const list = $('list');
  const items = filtered();
  list.textContent = '';
  $('count').textContent = songs.length ? `${songs.length} song${songs.length === 1 ? '' : 's'}` : '';
  const empty = $('empty');
  empty.classList.toggle('hidden', items.length > 0);
  if (!items.length) {
    empty.textContent = songs.length ? 'No songs match your search.' : 'No songs yet. Check back soon.';
  }
  for (const s of items) {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'row' + (current && current.id === s.id ? ' active' : '') +
      (current && current.id === s.id && !audio.paused ? ' playing' : '');
    btn.dataset.id = s.id;

    const thumb = document.createElement('div');
    thumb.className = 'thumb';
    paintArt(thumb, s);

    const t = document.createElement('div');
    t.className = 't';
    const b = document.createElement('b');
    b.textContent = s.title;
    const sp = document.createElement('span');
    sp.textContent = s.artist || 'Unknown artist';
    t.append(b, sp);

    const d = document.createElement('div');
    d.className = 'd';
    const eq = document.createElement('span');
    eq.className = 'eq';
    eq.innerHTML = '<i></i><i></i><i></i>';
    const dur = document.createElement('span');
    dur.textContent = s.duration ? fmtTime(s.duration) : '';
    d.append(eq, dur);

    btn.append(thumb, t, d);
    btn.addEventListener('click', () => {
      if (current && current.id === s.id) togglePlay();
      else playSong(s);
    });
    li.appendChild(btn);
    list.appendChild(li);
  }
}

function markRows() {
  document.querySelectorAll('.row').forEach((r) => {
    const on = current && r.dataset.id === current.id;
    r.classList.toggle('active', !!on);
    r.classList.toggle('playing', !!on && !audio.paused);
  });
}

async function loadSongs(initial) {
  try {
    const data = await api('/api/songs');
    const sig = JSON.stringify(data);
    if (sig === lastSig) return;
    lastSig = sig;
    songs = data;
    if (current) {
      const fresh = songs.find((s) => s.id === current.id);
      if (fresh) current = fresh; // keep playing even if edited
    }
    render();
  } catch (e) {
    if (initial) {
      $('empty').classList.remove('hidden');
      $('empty').textContent = 'Could not load the library. Please refresh.';
    }
  }
}

/* ---------- playback ---------- */
function showNowPlaying() {
  $('title').textContent = current ? current.title : 'Select a song';
  $('artist').textContent = current ? (current.artist || 'Unknown artist') : 'Choose something from the library';
  paintArt($('art'), current);
  document.title = current ? `${current.title} · SK Music` : 'SK Music Player';
  if ('mediaSession' in navigator && current) {
    const meta = { title: current.title, artist: current.artist || '' };
    if (current.hasArt) {
      meta.artwork = [{ src: `/api/songs/${current.id}/art?v=${current.v || 0}`, sizes: '512x512' }];
    }
    try { navigator.mediaSession.metadata = new MediaMetadata(meta); } catch (_) { /* ignore */ }
  }
}

function playSong(s) {
  current = s;
  audio.src = `/api/songs/${s.id}/stream`;
  showNowPlaying();
  $('seek').value = 0; setRange($('seek'));
  $('cur').textContent = '0:00';
  $('dur').textContent = s.duration ? fmtTime(s.duration) : '0:00';
  const p = audio.play();
  if (p && p.catch) p.catch(() => { /* needs a tap on some browsers */ });
  markRows();
}

function togglePlay() {
  if (!current) {
    const first = filtered()[0];
    if (first) playSong(first);
    return;
  }
  if (audio.paused) audio.play().catch(() => {}); else audio.pause();
}

function queue() {
  const f = filtered();
  return current && !f.some((s) => s.id === current.id) ? songs : f;
}

function step(dir, auto) {
  const q = queue();
  if (!q.length) return;
  if (shuffle && q.length > 1) {
    let n;
    do { n = q[Math.floor(Math.random() * q.length)]; } while (current && n.id === current.id);
    return playSong(n);
  }
  const i = current ? q.findIndex((s) => s.id === current.id) : -1;
  let n = i + dir;
  if (n >= q.length) {
    if (auto && !repeat) { audio.pause(); audio.currentTime = 0; return; }
    n = 0;
  }
  if (n < 0) n = q.length - 1;
  playSong(q[n]);
}

function prev() {
  if (audio.currentTime > 3) audio.currentTime = 0; else step(-1);
}

/* ---------- wiring ---------- */
$('play').innerHTML = ICON.play;
$('play').addEventListener('click', togglePlay);
$('next').addEventListener('click', () => step(1));
$('prev').addEventListener('click', prev);
$('shuffle').addEventListener('click', (e) => { shuffle = !shuffle; e.currentTarget.classList.toggle('on', shuffle); });
$('repeat').addEventListener('click', (e) => { repeat = !repeat; e.currentTarget.classList.toggle('on', repeat); });
$('q').addEventListener('input', render);

audio.addEventListener('play', () => { $('play').innerHTML = ICON.pause; $('play').title = 'Pause'; markRows(); });
audio.addEventListener('pause', () => { $('play').innerHTML = ICON.play; $('play').title = 'Play'; markRows(); });
audio.addEventListener('loadedmetadata', () => { if (isFinite(audio.duration)) $('dur').textContent = fmtTime(audio.duration); });
audio.addEventListener('timeupdate', () => {
  if (dragging || !isFinite(audio.duration) || !audio.duration) return;
  $('seek').value = (audio.currentTime / audio.duration) * 1000;
  setRange($('seek'));
  $('cur').textContent = fmtTime(audio.currentTime);
});
audio.addEventListener('ended', () => {
  if (repeat && queue().length === 1) { audio.currentTime = 0; audio.play(); } else step(1, true);
});
audio.addEventListener('error', () => {
  if (current) { $('artist').textContent = 'Could not play this song'; }
});

const seek = $('seek');
seek.addEventListener('input', () => {
  dragging = true;
  setRange(seek);
  if (isFinite(audio.duration)) $('cur').textContent = fmtTime((seek.value / 1000) * audio.duration);
});
seek.addEventListener('change', () => {
  if (isFinite(audio.duration)) audio.currentTime = (seek.value / 1000) * audio.duration;
  dragging = false;
});

const vol = $('volume');
function applyVolume() {
  audio.volume = vol.value / 100;
  setRange(vol);
  $('mute').innerHTML = audio.muted || vol.value === '0' ? ICON.mute : ICON.vol;
}
vol.value = store.get('vol', '80');
vol.addEventListener('input', () => { audio.muted = false; applyVolume(); store.set('vol', vol.value); });
$('mute').addEventListener('click', () => { audio.muted = !audio.muted; applyVolume(); });
applyVolume();

/* Hardware / lock-screen controls on phones */
if ('mediaSession' in navigator) {
  const set = (a, f) => { try { navigator.mediaSession.setActionHandler(a, f); } catch (_) { /* unsupported */ } };
  set('play', () => audio.play());
  set('pause', () => audio.pause());
  set('previoustrack', prev);
  set('nexttrack', () => step(1));
  set('seekto', (d) => { if (d.seekTime != null) audio.currentTime = d.seekTime; });
}

/* Keyboard: space = play/pause, arrows = seek */
document.addEventListener('keydown', (e) => {
  if (/INPUT|TEXTAREA/.test(document.activeElement.tagName) && document.activeElement.type !== 'range') return;
  if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
  else if (e.code === 'ArrowRight' && e.shiftKey) step(1);
  else if (e.code === 'ArrowLeft' && e.shiftKey) prev();
});

/* Library refreshes itself so new uploads appear without a reload */
loadSongs(true);
setInterval(loadSongs, 10000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) loadSongs(); });
showNowPlaying();
