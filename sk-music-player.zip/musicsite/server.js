'use strict';
/*
 * SK Music Player: zero-dependency Node.js server (Node 18+).
 * Serves the website, streams MP3s with HTTP range support, and exposes a
 * protected admin API for uploading, editing and deleting songs.
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

/* ------------------------------------------------------------------ */
/* Configuration                                                       */
/* ------------------------------------------------------------------ */
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const PUBLIC_DIR = path.join(__dirname, 'public');
const AUDIO_DIR = path.join(DATA_DIR, 'audio');
const ART_DIR = path.join(DATA_DIR, 'art');
const DB_FILE = path.join(DATA_DIR, 'songs.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const SECRET_FILE = path.join(DATA_DIR, 'session.key');
const MAX_AUDIO = (Number(process.env.MAX_AUDIO_MB) || 50) * 1024 * 1024;
const MAX_ART = 5 * 1024 * 1024;
const TRUST_PROXY = process.env.TRUST_PROXY === '1'; // set when behind Render/Railway/nginx etc.
const SESSION_HOURS = 12;
const COOKIE = 'sid';

for (const d of [DATA_DIR, AUDIO_DIR, ART_DIR]) fs.mkdirSync(d, { recursive: true });

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

/* ------------------------------------------------------------------ */
/* Secrets and admin account (credentials live only on the server)     */
/* ------------------------------------------------------------------ */
function loadSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  if (fs.existsSync(SECRET_FILE)) return fs.readFileSync(SECRET_FILE, 'utf8').trim();
  const s = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(SECRET_FILE, s, { mode: 0o600 });
  return s;
}
const SECRET = loadSecret();

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();

function setupAdmin() {
  const user = process.env.ADMIN_USER;
  const pass = process.env.ADMIN_PASSWORD;
  if (user && pass) {
    let current = null;
    try { current = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8')); } catch (_) { /* first run */ }
    const unchanged = current && current.user === user && hashPw(pass, current.salt) === current.hash;
    if (!unchanged) {
      const salt = crypto.randomBytes(16).toString('hex');
      fs.writeFileSync(ADMIN_FILE, JSON.stringify({ user, salt, hash: hashPw(pass, salt) }), { mode: 0o600 });
      console.log('Admin account configured (password stored as a salted scrypt hash).');
    }
  } else if (!fs.existsSync(ADMIN_FILE)) {
    console.error('No admin account yet. Start once with ADMIN_USER and ADMIN_PASSWORD set.');
    process.exit(1);
  }
}
setupAdmin();
const getAdmin = () => JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8'));

/* ------------------------------------------------------------------ */
/* Sessions: signed, expiring, HttpOnly + SameSite=Strict cookie       */
/* ------------------------------------------------------------------ */
function sign(exp) {
  // Changing the admin password changes this key, which invalidates every old session.
  return crypto.createHmac('sha256', SECRET + getAdmin().hash).update(String(exp)).digest('hex');
}
const makeToken = () => {
  const exp = Date.now() + SESSION_HOURS * 3600 * 1000;
  return `${exp}.${sign(exp)}`;
};
function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) {
      try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch (_) { /* skip */ }
    }
  }
  return out;
}
function isAdmin(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return false;
  const [exp, mac] = token.split('.');
  if (!exp || !mac || !(Number(exp) > Date.now())) return false;
  const good = sign(exp);
  return mac.length === good.length && crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(good));
}
const isHttps = (req) =>
  !!req.socket.encrypted || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https');
function setCookie(res, req, value, maxAgeSec) {
  res.setHeader('Set-Cookie',
    `${COOKIE}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}` +
    (isHttps(req) ? '; Secure' : ''));
}
function clientIp(req) {
  if (TRUST_PROXY && req.headers['x-forwarded-for']) {
    return req.headers['x-forwarded-for'].split(',').pop().trim(); // entry added by our proxy
  }
  return req.socket.remoteAddress || 'unknown';
}

/* Login throttling: 5 failures per IP per 15 minutes */
const WINDOW = 15 * 60 * 1000;
const fails = new Map();
function throttled(ip) {
  const r = fails.get(ip);
  if (!r) return false;
  if (Date.now() - r.first > WINDOW) { fails.delete(ip); return false; }
  return r.count >= 5;
}
function noteFail(ip) {
  const r = fails.get(ip);
  if (!r || Date.now() - r.first > WINDOW) fails.set(ip, { count: 1, first: Date.now() });
  else r.count++;
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, r] of fails) if (now - r.first > WINDOW) fails.delete(ip);
}, WINDOW).unref();

/* ------------------------------------------------------------------ */
/* Song database (JSON on the persistent disk, atomic writes)          */
/* ------------------------------------------------------------------ */
let songs = [];
try { songs = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (_) { songs = []; }
function saveDb() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(songs, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
const publicSong = (s) => ({
  id: s.id, title: s.title, artist: s.artist, duration: s.duration,
  hasArt: !!s.art, createdAt: s.createdAt, v: s.v || 0
});
const findSong = (id) => songs.find((s) => s.id === id);
const safeUnlink = (p) => { try { fs.unlinkSync(p); } catch (_) { /* ignore */ } };

/* ------------------------------------------------------------------ */
/* Content validation by magic bytes, not just file extension          */
/* ------------------------------------------------------------------ */
function readHead(file, n = 12) {
  const fd = fs.openSync(file, 'r');
  const buf = Buffer.alloc(n);
  fs.readSync(fd, buf, 0, n, 0);
  fs.closeSync(fd);
  return buf;
}
const isMp3 = (b) =>
  b.slice(0, 3).toString('latin1') === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0);
function imageExt(b) {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return '.jpg';
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return '.png';
  if (b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP') return '.webp';
  return null;
}
const ART_MIME = { '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };
const cleanText = (v, max) => String(v || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);
const discard = (files) => Object.values(files || {}).forEach((f) => safeUnlink(f.path));

function finalizeArt(file) {
  if (file.size > MAX_ART) throw new HttpError(400, 'Artwork must be 5 MB or smaller');
  const ext = imageExt(readHead(file.path));
  if (!ext) throw new HttpError(400, 'Artwork must be a JPG, PNG or WebP image');
  const name = path.basename(file.path, '.tmp') + ext;
  fs.renameSync(file.path, path.join(ART_DIR, name));
  file.path = path.join(ART_DIR, name);
  return name;
}

/* ------------------------------------------------------------------ */
/* Streaming multipart/form-data parser (writes files straight to disk) */
/* ------------------------------------------------------------------ */
function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(req.headers['content-type'] || '');
    if (!/^multipart\/form-data/i.test(req.headers['content-type'] || '') || !m) {
      req.resume();
      return reject(new HttpError(400, 'Expected a file upload form'));
    }
    const delim = Buffer.from('\r\n--' + (m[1] || m[2]).trim());
    const fields = {};
    const files = {};
    const pending = [];
    let buf = Buffer.from('\r\n'); // virtual CRLF so the first boundary matches the delimiter
    let state = 'seek';
    let cur = null;
    let settled = false;
    let nFields = 0;

    function fail(err) {
      if (settled) return;
      settled = true;
      if (cur && cur.ws) cur.ws.destroy();
      discard(files);
      req.resume(); // drain the rest so the browser can read our error response
      reject(err instanceof HttpError ? err : new HttpError(400, 'Upload failed'));
    }

    function startPart(head) {
      const disp = /^content-disposition:\s*([^\r\n]*)/im.exec(head);
      if (!disp) return fail(new HttpError(400, 'Malformed upload'));
      const name = (/(?:^|;\s*)name="([^"]*)"/.exec(disp[1]) || [])[1];
      const fn = /(?:^|;\s*)filename="([^"]*)"/.exec(disp[1]);
      if (name === undefined) return fail(new HttpError(400, 'Malformed upload'));
      if (fn) {
        if (name !== 'audio' && name !== 'art') return fail(new HttpError(400, 'Unexpected file field'));
        if (files[name]) return fail(new HttpError(400, 'Duplicate file field'));
        const p = path.join(name === 'art' ? ART_DIR : AUDIO_DIR,
          crypto.randomBytes(16).toString('hex') + (name === 'art' ? '.tmp' : '.mp3'));
        const ws = fs.createWriteStream(p, { mode: 0o600 });
        ws.on('error', () => fail(new HttpError(500, 'Could not store file')));
        files[name] = { path: p, size: 0, originalname: fn[1] };
        cur = { kind: 'file', name, ws, size: 0, max: name === 'art' ? MAX_ART : MAX_AUDIO };
      } else {
        if (++nFields > 8) return fail(new HttpError(400, 'Too many fields'));
        cur = { kind: 'field', name, chunks: [], size: 0, max: 10 * 1024 };
      }
    }

    function write(chunk) {
      if (!chunk.length || settled) return;
      cur.size += chunk.length;
      if (cur.size > cur.max) {
        return fail(new HttpError(413, cur.kind === 'file'
          ? `${cur.name === 'art' ? 'Artwork' : 'File'} is too large (limit ${Math.round(cur.max / 1048576)} MB)`
          : 'Field too long'));
      }
      if (cur.kind === 'file') {
        if (!cur.ws.write(chunk)) { // honour disk back-pressure
          req.pause();
          cur.ws.once('drain', () => req.resume());
        }
      } else cur.chunks.push(chunk);
    }

    function endPart() {
      if (cur.kind === 'file') {
        files[cur.name].size = cur.size;
        const ws = cur.ws;
        pending.push(new Promise((r) => ws.once('finish', r)));
        ws.end();
      } else {
        fields[cur.name] = Buffer.concat(cur.chunks).toString('utf8');
      }
      cur = null;
    }

    function consume() {
      while (!settled) {
        if (state === 'seek') {
          const i = buf.indexOf(delim);
          if (i < 0) { buf = buf.slice(Math.max(0, buf.length - delim.length + 1)); return; }
          buf = buf.slice(i + delim.length);
          state = 'after';
        } else if (state === 'after') {
          if (buf.length < 2) return;
          const t = buf.slice(0, 2).toString('latin1');
          if (t === '--') {
            state = 'end';
            settled = true;
            Promise.all(pending).then(() => resolve({ fields, files }));
            return;
          }
          if (t !== '\r\n') return fail(new HttpError(400, 'Malformed upload'));
          buf = buf.slice(2);
          state = 'headers';
        } else if (state === 'headers') {
          const i = buf.indexOf('\r\n\r\n');
          if (i < 0) {
            if (buf.length > 16 * 1024) fail(new HttpError(400, 'Malformed upload'));
            return;
          }
          const head = buf.slice(0, i).toString('utf8');
          buf = buf.slice(i + 4);
          startPart(head);
          state = 'body';
        } else if (state === 'body') {
          const i = buf.indexOf(delim);
          if (i >= 0) {
            write(buf.slice(0, i));
            if (settled) return;
            endPart();
            buf = buf.slice(i + delim.length);
            state = 'after';
          } else {
            const keep = delim.length - 1;
            if (buf.length > keep) {
              write(buf.slice(0, buf.length - keep));
              buf = buf.slice(buf.length - keep);
            }
            return;
          }
        } else return;
      }
    }

    req.on('data', (chunk) => {
      if (settled) return;
      buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
      consume();
    });
    req.on('end', () => { if (!settled) fail(new HttpError(400, 'Incomplete upload')); });
    req.on('error', () => fail(new HttpError(400, 'Upload interrupted')));
    req.on('close', () => { if (!settled) fail(new HttpError(400, 'Upload interrupted')); });
  });
}

/* ------------------------------------------------------------------ */
/* HTTP helpers                                                        */
/* ------------------------------------------------------------------ */
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function readJson(req, limit = 10 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Request too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch (_) { reject(new HttpError(400, 'Bad request')); }
    });
    req.on('error', () => reject(new HttpError(400, 'Bad request')));
  });
}

/* Serve a file with Range support (needed for seeking and iOS/Safari playback) */
function serveFile(req, res, file, type, cache, extra) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const size = st.size;
    let start = 0;
    let end = size - 1;
    let status = 200;
    const headers = Object.assign({
      'Content-Type': type, 'Accept-Ranges': 'bytes', 'Cache-Control': cache,
      'Last-Modified': st.mtime.toUTCString()
    }, extra || {});
    const range = req.headers.range;
    if (range && size > 0) {
      const r = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
      if (!r || (r[1] === '' && r[2] === '')) {
        res.writeHead(416, { 'Content-Range': `bytes */${size}` });
        return res.end();
      }
      if (r[1] === '') { start = Math.max(size - Number(r[2]), 0); }
      else { start = Number(r[1]); if (r[2] !== '') end = Math.min(Number(r[2]), size - 1); }
      if (start > end || start >= size) {
        res.writeHead(416, { 'Content-Range': `bytes */${size}` });
        return res.end();
      }
      status = 206;
      headers['Content-Range'] = `bytes ${start}-${end}/${size}`;
    }
    headers['Content-Length'] = size === 0 ? 0 : end - start + 1;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || size === 0) return res.end();
    const rs = fs.createReadStream(file, { start, end });
    rs.on('error', () => res.destroy());
    res.on('close', () => rs.destroy());
    rs.pipe(res);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8'
};

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
  let rel;
  try { rel = decodeURIComponent(pathname); } catch (_) { throw new HttpError(400, 'Bad request'); }
  if (rel.includes('\0')) throw new HttpError(400, 'Bad request');
  if (rel === '/') rel = '/index.html';
  else if (rel === '/admin' || rel === '/admin/') rel = '/admin.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(404, 'Not found');
  if (path.basename(file).startsWith('.')) throw new HttpError(404, 'Not found');
  const type = MIME[path.extname(file).toLowerCase()];
  if (!type) throw new HttpError(404, 'Not found');
  serveFile(req, res, file, type, 'public, max-age=300');
}

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */
function requireAdmin(req) {
  if (!isAdmin(req)) throw new HttpError(401, 'Admin login required');
}
function checkUploadSize(req) {
  const len = Number(req.headers['content-length']);
  if (Number.isFinite(len) && len > MAX_AUDIO + MAX_ART + 1024 * 1024) {
    throw new HttpError(413, `File is too large (limit ${Math.round(MAX_AUDIO / 1048576)} MB)`);
  }
}

async function handleApi(req, res, pathname) {
  res.setHeader('Cache-Control', 'no-store');
  const method = req.method;

  // CSRF defence on top of SameSite=Strict: state-changing calls must carry a custom header
  if (method !== 'GET' && method !== 'HEAD' && req.headers['x-requested-with'] !== 'fetch') {
    throw new HttpError(403, 'Forbidden');
  }

  if (pathname === '/api/login' && method === 'POST') {
    const ip = clientIp(req);
    if (throttled(ip)) throw new HttpError(429, 'Too many attempts. Try again in 15 minutes.');
    const { user, password } = await readJson(req);
    const admin = getAdmin();
    const userOk = typeof user === 'string' && crypto.timingSafeEqual(sha(user), sha(admin.user));
    let passOk = false;
    if (typeof password === 'string' && password.length < 1024) {
      const a = Buffer.from(hashPw(password, admin.salt), 'hex');
      const b = Buffer.from(admin.hash, 'hex');
      passOk = a.length === b.length && crypto.timingSafeEqual(a, b);
    }
    if (!userOk || !passOk) {
      noteFail(ip);
      throw new HttpError(401, 'Invalid User ID or password');
    }
    fails.delete(ip);
    setCookie(res, req, makeToken(), SESSION_HOURS * 3600);
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/logout' && method === 'POST') {
    setCookie(res, req, '', 0);
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/me' && method === 'GET') return sendJson(res, 200, { admin: isAdmin(req) });

  if (pathname === '/api/songs' && method === 'GET') {
    return sendJson(res, 200, songs.slice().sort((a, b) => b.createdAt - a.createdAt).map(publicSong));
  }

  if (pathname === '/api/songs' && method === 'POST') {
    requireAdmin(req); // checked BEFORE a single byte of the upload is read
    checkUploadSize(req);
    const { fields, files } = await parseMultipart(req);
    try {
      const audio = files.audio;
      if (!audio) throw new HttpError(400, 'Please choose an MP3 file');
      if (!isMp3(readHead(audio.path))) throw new HttpError(400, 'That file is not a valid MP3');
      const title = cleanText(fields.title, 120) ||
        cleanText(audio.originalname.replace(/\.mp3$/i, ''), 120) || 'Untitled';
      const art = files.art ? finalizeArt(files.art) : null;
      const dur = Number(fields.duration);
      const song = {
        id: crypto.randomBytes(8).toString('hex'),
        title,
        artist: cleanText(fields.artist, 120),
        file: path.basename(audio.path),
        art,
        duration: Number.isFinite(dur) && dur > 0 && dur < 86400 ? Math.round(dur) : 0,
        createdAt: Date.now(),
        v: 1
      };
      songs.push(song);
      saveDb();
      return sendJson(res, 201, publicSong(song));
    } catch (e) {
      discard(files);
      throw e;
    }
  }

  const m = /^\/api\/songs\/([a-f0-9]{16})(?:\/(stream|art))?$/.exec(pathname);
  if (m) {
    const s = findSong(m[1]);
    const sub = m[2];

    if (sub === 'stream' && (method === 'GET' || method === 'HEAD')) {
      if (!s) throw new HttpError(404, 'Not found');
      return serveFile(req, res, path.join(AUDIO_DIR, s.file), 'audio/mpeg', 'public, max-age=3600',
        { 'Content-Disposition': 'inline' });
    }
    if (sub === 'art' && (method === 'GET' || method === 'HEAD')) {
      if (!s || !s.art) throw new HttpError(404, 'Not found');
      return serveFile(req, res, path.join(ART_DIR, s.art),
        ART_MIME[path.extname(s.art)] || 'application/octet-stream', 'public, max-age=86400');
    }

    if (!sub && method === 'PATCH') {
      requireAdmin(req);
      checkUploadSize(req);
      const { fields, files } = await parseMultipart(req);
      try {
        if (!s) throw new HttpError(404, 'Song not found');
        if (files.audio) throw new HttpError(400, 'To replace audio, delete the song and upload again');
        if (fields.title !== undefined) {
          const t = cleanText(fields.title, 120);
          if (!t) throw new HttpError(400, 'Title cannot be empty');
          s.title = t;
        }
        if (fields.artist !== undefined) s.artist = cleanText(fields.artist, 120);
        if (files.art) {
          const newArt = finalizeArt(files.art);
          if (s.art) safeUnlink(path.join(ART_DIR, s.art));
          s.art = newArt;
          s.v = (s.v || 0) + 1;
        } else if (fields.removeArt === '1' && s.art) {
          safeUnlink(path.join(ART_DIR, s.art));
          s.art = null;
          s.v = (s.v || 0) + 1;
        }
        saveDb();
        return sendJson(res, 200, publicSong(s));
      } catch (e) {
        discard(files);
        throw e;
      }
    }

    if (!sub && method === 'DELETE') {
      requireAdmin(req);
      if (!s) throw new HttpError(404, 'Song not found');
      songs.splice(songs.indexOf(s), 1);
      saveDb();
      safeUnlink(path.join(AUDIO_DIR, s.file));
      if (s.art) safeUnlink(path.join(ART_DIR, s.art));
      return sendJson(res, 200, { ok: true });
    }
  }

  throw new HttpError(404, 'Not found');
}

/* ------------------------------------------------------------------ */
/* Server                                                              */
/* ------------------------------------------------------------------ */
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; " +
    "style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if (isHttps(req)) res.setHeader('Strict-Transport-Security', 'max-age=31536000');

  try {
    const pathname = new URL(req.url, 'http://localhost').pathname;
    if (pathname.startsWith('/api/')) await handleApi(req, res, pathname);
    else serveStatic(req, res, pathname);
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    if (status === 500) console.error(err);
    if (res.headersSent) return res.destroy();
    const body = JSON.stringify({ error: status === 500 ? 'Server error' : err.message });
    const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) };
    if (status === 413) headers.Connection = 'close';
    res.writeHead(status, headers);
    res.end(body);
  }
});

server.requestTimeout = 30 * 60 * 1000; // allow slow mobile uploads of large MP3s
server.headersTimeout = 60 * 1000;
server.keepAliveTimeout = 65 * 1000;
server.listen(PORT, () => console.log(`SK Music Player running on port ${PORT} (data: ${DATA_DIR})`));
