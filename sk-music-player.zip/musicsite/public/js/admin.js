'use strict';

const $ = (id) => document.getElementById(id);
let songs = [];

function show(view) {
  $('loginView').classList.toggle('hidden', view !== 'login');
  $('dash').classList.toggle('hidden', view !== 'dash');
  $('logout').classList.toggle('hidden', view !== 'dash');
}

function say(el, text, kind) {
  el.textContent = text || '';
  el.className = 'msg' + (kind ? ' ' + kind : '');
}

/* Any 401 means the session ended: go back to login */
function handleAuthError(e) {
  if (e && e.status === 401) { show('login'); say($('loginMsg'), 'Session expired. Please sign in again.', 'err'); return true; }
  return false;
}

async function init() {
  try {
    const me = await api('/api/me');
    if (me.admin) { show('dash'); await refresh(); } else show('login');
  } catch (_) { show('login'); }
}

/* ---------- login / logout ---------- */
$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('loginBtn');
  btn.disabled = true;
  say($('loginMsg'), '');
  try {
    await api('/api/login', { method: 'POST', body: { user: $('user').value.trim(), password: $('pass').value } });
    $('pass').value = '';
    show('dash');
    await refresh();
  } catch (err) {
    say($('loginMsg'), err.message, 'err');
  } finally { btn.disabled = false; }
});

$('logout').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch (_) { /* ignore */ }
  songs = [];
  show('login');
});

/* ---------- library management ---------- */
async function refresh() {
  try {
    songs = await api('/api/songs');
    renderList();
  } catch (e) { handleAuthError(e); }
}

function renderList() {
  const box = $('aList');
  box.textContent = '';
  $('aCount').textContent = songs.length ? `(${songs.length})` : '';
  $('aEmpty').classList.toggle('hidden', songs.length > 0);
  for (const s of songs) box.appendChild(rowFor(s));
}

function rowFor(s) {
  const row = document.createElement('div');
  row.className = 'arow';

  const thumb = document.createElement('div');
  thumb.className = 'thumb';
  paintArt(thumb, s);

  const t = document.createElement('div');
  t.className = 't';
  const b = document.createElement('b');
  b.textContent = s.title;
  const sp = document.createElement('span');
  sp.textContent = (s.artist || 'Unknown artist') + (s.duration ? ' · ' + fmtTime(s.duration) : '');
  t.append(b, sp);

  const acts = document.createElement('div');
  acts.className = 'acts';
  const edit = button('Edit', 'btn ghost sm');
  const del = button('Delete', 'btn danger sm');
  acts.append(edit, del);
  row.append(thumb, t, acts);

  /* inline editor */
  const form = document.createElement('form');
  form.className = 'edit hidden';
  const iTitle = input('Title', s.title, 120);
  const iArtist = input('Artist', s.artist || '', 120);
  const artWrap = document.createElement('div');
  artWrap.className = 'full';
  const artLabel = document.createElement('label');
  artLabel.textContent = 'Replace artwork (optional)';
  const iArt = document.createElement('input');
  iArt.type = 'file';
  iArt.className = 'field';
  iArt.accept = 'image/jpeg,image/png,image/webp';
  artWrap.append(artLabel, iArt);
  const btns = document.createElement('div');
  btns.className = 'row-btns';
  const save = button('Save', 'btn sm');
  save.type = 'submit';
  const cancel = button('Cancel', 'btn ghost sm');
  btns.append(save, cancel);
  let removeBtn = null;
  if (s.hasArt) { removeBtn = button('Remove artwork', 'btn danger sm'); btns.append(removeBtn); }
  const fmsg = document.createElement('div');
  fmsg.className = 'msg full';
  fmsg.style.gridColumn = '1 / -1';
  form.append(iTitle.wrap, iArtist.wrap, artWrap, btns, fmsg);
  row.appendChild(form);

  edit.addEventListener('click', () => form.classList.toggle('hidden'));
  cancel.addEventListener('click', () => form.classList.add('hidden'));

  async function patch(fd) {
    save.disabled = true;
    say(fmsg, 'Saving…');
    try {
      await api(`/api/songs/${s.id}`, { method: 'PATCH', body: fd });
      await refresh();
    } catch (e) {
      if (!handleAuthError(e)) say(fmsg, e.message, 'err');
    } finally { save.disabled = false; }
  }
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData();
    fd.append('title', iTitle.el.value);
    fd.append('artist', iArtist.el.value);
    if (iArt.files[0]) fd.append('art', iArt.files[0]);
    patch(fd);
  });
  if (removeBtn) removeBtn.addEventListener('click', () => {
    const fd = new FormData();
    fd.append('title', iTitle.el.value);
    fd.append('removeArt', '1');
    patch(fd);
  });

  del.addEventListener('click', async () => {
    if (!confirm(`Delete "${s.title}" permanently?`)) return;
    del.disabled = true;
    try {
      await api(`/api/songs/${s.id}`, { method: 'DELETE' });
      await refresh();
    } catch (e) {
      del.disabled = false;
      if (!handleAuthError(e)) alert(e.message);
    }
  });
  return row;
}

function button(text, cls) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = cls;
  b.textContent = text;
  return b;
}
function input(label, value, max) {
  const wrap = document.createElement('div');
  const l = document.createElement('label');
  l.textContent = label;
  const el = document.createElement('input');
  el.className = 'field';
  el.value = value;
  el.maxLength = max;
  wrap.append(l, el);
  return { wrap, el };
}

/* ---------- upload ---------- */
$('fArt').addEventListener('change', () => {
  const f = $('fArt').files[0];
  const prev = $('artPrev');
  if (!f) { prev.classList.add('hidden'); return; }
  const url = URL.createObjectURL(f);
  $('artThumb').style.backgroundImage = `url(${url})`;
  $('artThumb').textContent = '';
  prev.classList.remove('hidden');
});

/* Read duration in the browser so the library can show it */
function audioDuration(file) {
  return new Promise((resolve) => {
    const a = new Audio();
    const url = URL.createObjectURL(file);
    const done = (v) => { URL.revokeObjectURL(url); resolve(v); };
    a.preload = 'metadata';
    a.onloadedmetadata = () => done(isFinite(a.duration) ? a.duration : 0);
    a.onerror = () => done(0);
    a.src = url;
  });
}

$('fAudio').addEventListener('change', () => {
  const f = $('fAudio').files[0];
  if (f && !$('fTitle').value) $('fTitle').value = f.name.replace(/\.mp3$/i, '');
});

$('upForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const audio = $('fAudio').files[0];
  if (!audio) return say($('upMsg'), 'Please choose an MP3 file.', 'err');
  if (!/\.mp3$/i.test(audio.name) && audio.type !== 'audio/mpeg') return say($('upMsg'), 'Only MP3 files are allowed.', 'err');
  $('upBtn').disabled = true;
  say($('upMsg'), 'Preparing…');

  const fd = new FormData();
  fd.append('title', $('fTitle').value);
  fd.append('artist', $('fArtist').value);
  fd.append('duration', String(await audioDuration(audio)));
  fd.append('audio', audio);
  if ($('fArt').files[0]) fd.append('art', $('fArt').files[0]);

  const bar = $('bar');
  bar.style.display = 'block';
  $('barFill').style.width = '0%';

  /* XHR gives real upload progress, which matters for big files on mobile */
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/songs');
  xhr.setRequestHeader('X-Requested-With', 'fetch');
  xhr.upload.onprogress = (ev) => {
    if (ev.lengthComputable) {
      const pct = Math.round((ev.loaded / ev.total) * 100);
      $('barFill').style.width = pct + '%';
      say($('upMsg'), `Uploading… ${pct}%`);
    }
  };
  xhr.onload = async () => {
    let data = {};
    try { data = JSON.parse(xhr.responseText); } catch (_) { /* ignore */ }
    $('upBtn').disabled = false;
    bar.style.display = 'none';
    if (xhr.status === 201) {
      say($('upMsg'), `"${data.title}" uploaded and live.`, 'ok');
      $('upForm').reset();
      $('artPrev').classList.add('hidden');
      await refresh();
    } else if (xhr.status === 401) {
      show('login');
      say($('loginMsg'), 'Session expired. Please sign in again.', 'err');
    } else {
      say($('upMsg'), data.error || `Upload failed (${xhr.status})`, 'err');
    }
  };
  xhr.onerror = () => {
    $('upBtn').disabled = false;
    bar.style.display = 'none';
    say($('upMsg'), 'Network error. Please try again.', 'err');
  };
  xhr.send(fd);
});

init();
