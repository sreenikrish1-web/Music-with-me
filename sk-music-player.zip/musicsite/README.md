# SK Music Player

Zero-dependency Node.js (18+) MP3 streaming site with a protected admin dashboard.

- Public site: `/`  (browse, search, stream)
- Admin: `/admin`  (login, upload MP3 + artwork, edit, delete)

## Run locally
    ADMIN_USER=Admin ADMIN_PASSWORD='Sk@admin' node server.js
    # open http://localhost:3000

The credentials are only read from environment variables on the server, hashed with
scrypt and stored in `DATA_DIR/admin.json`. They are not in any source file.
After the first start you can drop the env vars. Changing `ADMIN_PASSWORD` later and
restarting resets the password and logs out all sessions.

## Deploy (needs a host with a persistent disk, otherwise uploads vanish on redeploy)
Set: `DATA_DIR` (path of the persistent disk), `TRUST_PROXY=1`, `ADMIN_USER`, `ADMIN_PASSWORD`.

- **Render**: push this folder to GitHub, New > Blueprint, pick the repo (uses render.yaml),
  enter ADMIN_PASSWORD when asked. Disk requires a paid plan.
- **Railway / Fly.io**: deploy the Dockerfile, attach a volume mounted at `/data`, set the env vars.
- **Any VPS**: `node server.js` behind nginx/Caddy for HTTPS, `DATA_DIR=/srv/music`.

Always serve over HTTPS in production (cookies are marked Secure automatically behind a proxy).

## Security notes
Server-side auth with signed HttpOnly SameSite=Strict cookie; login lockout (5 tries / 15 min);
uploads require admin before any byte is read; MP3/image content verified by magic bytes;
random stored filenames; CSRF header check; CSP and security headers; path-traversal safe.
Limits: 50 MB per MP3 (`MAX_AUDIO_MB`), 5 MB artwork.
Streaming is inline (no download button), but any browser can technically save audio it plays.
