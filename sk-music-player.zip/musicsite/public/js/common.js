'use strict';
/* Shared helpers (no secrets here; authentication is entirely server-side). */
const NOTE_SVG =
  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z"/></svg>';

function fmtTime(sec) {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = String(sec % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

/* Deterministic gradient for songs without artwork */
function gradientFor(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) >>> 0;
  const h1 = h % 360;
  const h2 = (h1 + 50 + (h % 70)) % 360;
  return `linear-gradient(135deg, hsl(${h1} 70% 45%), hsl(${h2} 75% 35%))`;
}

/* Paint artwork (or a gradient placeholder) onto an element */
function paintArt(el, song) {
  if (song && song.hasArt) {
    el.style.backgroundImage = `url(/api/songs/${song.id}/art?v=${song.v || 0})`;
    el.innerHTML = '';
  } else {
    el.style.backgroundImage = gradientFor(song ? song.title + song.id : 'music');
    el.innerHTML = NOTE_SVG;
  }
}

async function api(path, opts = {}) {
  const headers = Object.assign({ 'X-Requested-With': 'fetch' }, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData) && typeof body === 'object') {
    body = JSON.stringify(body);
    headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(path, { method: opts.method || 'GET', headers, body, credentials: 'same-origin' });
  let data = null;
  try { data = await res.json(); } catch (_) { /* no body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function setRange(el) {
  const max = Number(el.max) || 100;
  el.style.setProperty('--p', `${(Number(el.value) / max) * 100}%`);
}
